% Tucker Emmett and Severyn Polakiewicz
% Simple function that takes in ode45 data from the second homework in
% Aerospace Software and generates images based on the optimization.

function [] = odePlotter(t,y)

y = y./1000;

[One] = plotter(y(:,1),y(:,2),'asdf','asdf','ast','b',2);
hold on;
plot(y(1,1),y(1,2),'go','LineWidth',4);
three = quiver(y(1,1),y(1,2),1.8183,46.0977,'r','LineWidth',3);

hold on;
[Two] = plotter(y(:,5),y(:,6),'X (km)','Y(km)','Moon vs Satellite Behavior','k',2);
plot(y(1,5),y(1,6),'gd','LineWidth',4)
hold on;
h = [One;Two;three];

legend(h,'Satellite Path','Moon Path','Applied Delta V')



end
