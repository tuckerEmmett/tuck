% This function literally just exists to run the differential equation with
% the optimized velocity and plot the results.

function [ie] = odeCall_NoOpt(dV)
close all;
global G MassMoon MassEarth MassSat RadiusMoon RadiusEarth

G = 6.674e-11; % N*m/kg^2
MassMoon = 7.34767309e22; %kg
MassEarth = 5.97219e24; %kg
MassSat = 28833; %kg
RadiusMoon = 1737100; %m
RadiusEarth = 6371000; %m

v0Sat = 1000; %m/s
thetaSat = 50; %deg
dEarthSat = 340000000; %m
dEarthMoon = 384403000; %m
v0Moon = sqrt((G.*MassEarth.^2)./((MassEarth+MassMoon).*dEarthMoon));
thetaMoon = 42.5; %deg

%%% Create initial conditions for 
initials = zeros(8,1);

initials(1) = dEarthSat.*cosd(thetaSat);
initials(2) = dEarthSat.*sind(thetaSat);
initials(3) = v0Sat.*cosd(thetaSat);
initials(4) = v0Sat.*sind(thetaSat);
initials(5) = dEarthMoon.*cosd(thetaMoon); 
initials(6) = dEarthMoon.*sind(thetaMoon);
initials(7) = -v0Moon.*sind(thetaMoon);
initials(8) = v0Moon.*cosd(thetaMoon);


options = odeset('AbsTol',1e-10,'Events',@moonEvents);
initials(3) = initials(3) + dV(1);
initials(4) = initials(4) + dV(2);
[t,y,~,~,ie] = ode45(@odeForSatellite,[1,1e10],initials,options);
odePlotter(t,y)
end