% Tucker Emmett and Severyn Polakiewicz
% optDeltaV() runs through the ode45 call and outputs a value which needs
% to be optimized by fminsearch().

% deltaV is an input to allow the later optimization to input updated
% values during the optimiztion.

% targetedMin is the output. If the input deltaV allows the satellite to
% return to Earth, targetedMin is equal to the magnitude of the deltaV.
% Otherwise, targetedMin is equal to 1 million. The intention with this
% code is to force fminsearch() to recognize that return to Earth is the
% only  possible solution to the minimization problem.



function [targetedMin] = optDeltaV(deltaV)

close all;

G = 6.674e-11; % N*m/kg^2
MassMoon = 7.34767309e22; %kg
MassEarth = 5.97219e24; %kg
MassSat = 28833; %kg
RadiusMoon = 1737100; %m
RadiusEarth = 6371000; %m

v0Sat = 1000; %m/s
thetaSat = 50; %deg
dEarthSat = 340000000; %m
dEarthMoon = 384403000; %m
v0Moon = sqrt((G.*MassEarth.^2)./((MassEarth+MassMoon).*dEarthMoon));
thetaMoon = 42.5; %deg

%%% Create initial conditions for 
initials = zeros(8,1);

initials(1) = dEarthSat.*cosd(thetaSat);
initials(2) = dEarthSat.*sind(thetaSat);
initials(3) = v0Sat.*cosd(thetaSat) + deltaV(1);
initials(4) = v0Sat.*sind(thetaSat) + deltaV(2);
initials(5) = dEarthMoon.*cosd(thetaMoon); 
initials(6) = dEarthMoon.*sind(thetaMoon);
initials(7) = -v0Moon.*sind(thetaMoon);
initials(8) = v0Moon.*cosd(thetaMoon);

options = odeset('AbsTol',1e-15,'Events',@moonEvents);

[~,y,~,~,ie] = ode45(@(t,y)odeForSatellite(t,y),[1,1e9],initials,options);


% This section includes the interesting logic switches. If the event output
% from the above ode45 call says that the satellite returned to earth, then
% the output is the value that we want minimized. Otherwise, the output is
% a very large value such that fminsearch() recognizes a large positive
% gradient, and decides to pursue a different direction for minimization.

if ie == 1
    targetedMin = sqrt(deltaV(1).^2 + deltaV(2).^2);
    
else
    targetedMin = 1000000;
end


end
