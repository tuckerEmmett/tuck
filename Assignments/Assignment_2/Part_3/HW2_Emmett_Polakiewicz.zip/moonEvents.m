% Tucker Emmett and Severyn Polakiewicz
% moonEvents() takes care of moon impact, return to Earth, and losing the
% satellite to the depths of space.

% Inputs include the t and y variables from the overall ode45 call. 
% Outputs include value (zero when an event occurs), isterminal (1 when an
% event occurs), and direction (0 always).

function [value,isterminal,direction] = moonEvents(t,y)


RadiusMoon = 1737100; %m
RadiusEarth = 6371000; %m
% Determine if satellite has collided with moon and terminate if so.
dEarthMoon = 384403000;
returnEarth = (sqrt(y(1).^2 + y(2).^2) - RadiusEarth); 
crashMoon = sqrt(((y(1) - y(5)).^2)+((y(2) - y(6))^2)) - RadiusMoon; 
lostSpace = 2*dEarthMoon - (sqrt(y(1).^2 + y(2).^2)); 

% 
% % Note that all of the above doubles return the inverse of the actual
% % event. EX if the sat crashes into the moon, a zero will be returned.
% 
value = [ returnEarth, crashMoon, lostSpace];
isterminal = [1, 1, 1];
direction = [0, 0, 0];
% 





end
