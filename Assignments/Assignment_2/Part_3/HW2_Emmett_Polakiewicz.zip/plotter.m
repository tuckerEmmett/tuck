% Tucker Emmett and Matt Hurst
% ASEN 3128
% plotter.m
% Created: 09/1/2014
% Modified: 01/20/2016
% 
% This function offers an alternative to repetitively naming plots. It is a self-contained function in which
% variables including labels, titles, color options, and line width can all be changed.
% The order of inputs is as follows:
% (x, y, xLabel, yLabel, Tile, colorOptions, lineWidth)

function [Handle] = plotter(x,y,xLabel,yLabel,Title,colorOptions,lineWidth)

Handle = plot(x,y,colorOptions,'LineWidth',lineWidth);
xlabel(xLabel,'FontSize',20);
ylabel(yLabel,'FontSize',20);
title(Title,'FontSize',22);
grid on;

end