% Tucker Emmett and Severyn Polakiewicz

% odeForSatellite() is the overarching ode45 setup for the Equations of
% Motion for a three body problem involving the Earth, Moon, and a small
% satellite

% Inputs are time and initial "position" vector. Time is time in seconds
% and x_in is position and velocity for the satellite and the moon.

% dx is the only output variable. dx is a vector of satellite and moon
% velocity and acceleration.
function [dx] = odeForSatellite(t,x_in)

G = 6.674e-11; % N*m/kg^2
MassMoon = 7.34767309e22; %kg
MassEarth = 5.97219e24; %kg
MassSat = 28833; %kg
RadiusMoon = 1737100; %m
RadiusEarth = 6371000; %m

xSat = x_in(1);
ySat = x_in(2);
vxSat = x_in(3);
vySat = x_in(4);

xMoon = x_in(5);
yMoon = x_in(6);
vxMoon = x_in(7);
vyMoon = x_in(8);



distMoonSat = sqrt( (xSat - xMoon).^2 + (ySat - yMoon).^2); 

distEarthSat = sqrt(xSat.^2 + ySat.^2);

distEarthMoon = sqrt(xMoon.^2 + yMoon.^2);


dx = [0;0;0;0;0;0;0;0];

dx(1) = vxSat;
dx(2) = vySat;
dx(5) = vxMoon;
dx(6) = vyMoon;


F_MSx = (G.*MassMoon.*MassSat.*(xSat - xMoon))./(distMoonSat.^3);
F_MSy = (G.*MassMoon.*MassSat.*(ySat - yMoon))./(distMoonSat.^3);

F_ESx = (G.*MassEarth.*MassSat.*(xSat))./distEarthSat.^3;
F_ESy = (G.*MassEarth.*MassSat.*(ySat))./distEarthSat.^3;

F_EMx = (G.*MassEarth.*MassMoon.*(xMoon))./distEarthMoon.^3;
F_EMy = (G.*MassEarth.*MassMoon.*(yMoon))./distEarthMoon.^3;

dx(3) = (-F_MSx - F_ESx)./MassSat;% Satellite x acceleration
dx(4) = (-F_MSy - F_ESy)./MassSat;% Satellite y acceleration
dx(7) = (-F_EMx - F_MSx)./MassMoon;% Moon x acceleration
dx(8) = (-F_EMy - F_MSy)./MassMoon;% Moon y acceleration

end
