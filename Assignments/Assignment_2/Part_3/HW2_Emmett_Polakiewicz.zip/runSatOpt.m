% Tucker Emmett and Severyn Polakiewicz 
% This is the main file to run the satellite delta V optimization. 
% There are no inputs, but the optimized delta V vector and vector
% magnitude are displayed in the command window.
profile on
clear all; close all;
clc;
tic

options = optimset('MaxFunEvals',1000);

deltaV0 = [1,60];
%%% Use while loop to iterate until a very small change in velocity is
%%% reached.
percentChange = 1; 
% As per the document, we want a percent change of less than 0.5% from one iteration to the next
%to ensure that the solution is reaching an optimal value.
while (percentChange > 1e-4)
    % Run the optimizer
    [deltaVSoln,fVal,flag] = fminsearch(@(deltaV)optDeltaV(deltaV),deltaV0,options); 
    % Determine the percent change in solution magnitude since the last
    % iteration
    percentChange = abs(norm(deltaVSoln) - norm(deltaV0))./norm(deltaV0) 
    % Update the solution and continue iteration.
    deltaV0 = deltaVSoln;
    
end


deltaV_Components = deltaVSoln
deltaV_Required = norm(deltaVSoln)
odeCall_NoOpt(deltaVSoln);

toc

profile viewer