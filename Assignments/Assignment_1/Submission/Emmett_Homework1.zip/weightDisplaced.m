%%% Tucker Emmett for Aerospace Software. This function determines the
%%% weight of air displaced by the balloon at a given altitude. This is
%%% important in the later iterative process to find an altitude at which
%%% the weight of air displaced is no longer greater than the weight of the
%%% balloon.


function [W_air] = weightDisplaced(radius,altitude)
%%% assume balloon is perfect sphere

[T,P,rho] = tempPressureRho(altitude);

W_air = 4./3.*pi.*radius.^3.*rho;


end
