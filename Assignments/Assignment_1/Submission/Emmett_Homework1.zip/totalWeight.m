%%% Tucker Emmett for Aerospace Software. This function takes in a radius,
%%% payload weight, empty weight, and molecular weight, and calculates the
%%% total weight of the balloon.


function [weightTotal] = totalWeight(radius,weightPL,weightE,weightMol)

rhoSSL = 1.225; %kg/m^3

weightGas = (4.*pi.*rhoSSL.*radius.^3)./3.*(weightMol./28.966);

weightTotal = weightPL + weightE + weightGas;

end




