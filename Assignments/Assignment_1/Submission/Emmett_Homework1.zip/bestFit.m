%%% Tucker Emmett for Aerospace Software. This function takes in a set of
%%% data and determines a best fit line for the data (assuming that the
%%% data is roughly linear in nature). 

%%% Inputs: X and Y. Independent and dependent variables must have the same
%%%         vector size for this function to work.
%%% Outputs: m and b. The slope (m) and y-intercept (b) are singular
%%%          values, whereas the X and Y inputs are by nature vectors.


function [m,b] = bestFit(x,y)
%%% X, Y input; m, b output. If the sizes of X and Y are not the same then
%%% an error message will be returned. 
close all; clc;
if (size(x)) ~= (size(y))
    disp('Data series size is not consistent. X and Y data must be same size');
else
    N = length(x);
    A = sum(x);
    B = sum(y);
    midsumC(:) = x(:).*y(:);
    C = sum(midsumC);
    midsumD(:) = x(:).*x(:);
    D = sum(midsumD);
    
    m = (A.*B - N.*C)./(A.^2-N.*D);
    b = (A.*C - B.*D)./(A.^2 -N.*D);

end

end