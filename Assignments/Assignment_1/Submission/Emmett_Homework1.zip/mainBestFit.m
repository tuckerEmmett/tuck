%%% Tucker Emmett for Aerospace Software. This function throws the F-117
%%% Nighthawk data into the bestFit() function and determining the slope
%%% and intercept for this dataset.

%%% No inputs or outputs


function [] = mainBestFit() 

%%% This is a quick function to test out the bestFit function and apply it
%%% to the Nighthawk data as given in the problem statement.


alpha = [-5, -2, 0, 2, 3, 5, 7, 10, 14];
C_L = [-0.008,-0.003, 0.001, 0.005, 0.007, 0.006, 0.009, 0.017, 0.019];

[m,b] = bestFit(alpha,C_L); 

xFit = linspace(min(alpha),max(alpha));
yFit = linspace(min(C_L),max(C_L)); 

plotter(alpha,C_L,'alpha','C_{L}','C_{L}','bo',2);
hold on; 
plotter(xFit,yFit,'alpha','C_{L}','C_{L} vs alpha','k-',2);

legend('Raw Data','Best-Fit Line')
end

