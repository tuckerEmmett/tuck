%%% Tucker Emmett for Aerospace Software
%%% Homework 1, Problem 1 regarding the motion of a thrown object at some
%%% angle with some velocity. This solution should ideally mirror that
%%% provided by a software like ode45 with similar settings and inputs.

%%% The user is required to input three numbers; thetaDeg, vel, and dt. 

%%% thetaDeg is an angle in degrees. Any number is accepted, but negative
%%% values and values beyond 90 degrees lose physical significance for this
%%% problem

%%% vel is a simple velocity in m/s. Like with thetaDeg, numbers less than
%%% zero lose physical significance for this problem.

%%% dt is a delta time step value. Larger values (>>1) will result in an
%%% undersampled solution to a physical problem, while small values (<<1)
%%% will become computationally intensive.

%%% This script is written with the intention of taking a user input angle
%%% theta and initial speed V, and computing and plotting the horizontal
%%% and vertical displacements as a function of time. This script will use
%%% array arithmetic and the function which I developed a long time ago
%%% called 'plotter.m' 

close all; clear all; clc;

thetaDeg = input('Please enter a desired angle in degrees:');
vel = input('Please enter a desired velocity in meters per second:');
dt = input('What time step would you like (seconds)');



x0 = 0; 
y0 = 1;
 
vx = vel.*cosd(thetaDeg);
vy = vel.*sind(thetaDeg);


for ii = 1:1000
    y(1) = 0.001;
    if y(end) > 0
    y(1) = 0;
    x(1) = 0; 
    t(1) = 0;
    x(ii+1) = x(ii) + (dt).*vx;
    y(ii+1) = y(ii) + (dt).*vy + 0.5.*(-9.81).*(t(ii)+dt).^2;
    t(ii+1) = t(ii) + dt;
    ii = ii +1; 
    end        
end

 figure(1)
        subplot(1,2,1)
        plotter(t,x,'Time (s)','X (m)','X Position vs Time','b',2)
        subplot(1,2,2)
        plotter(t,y,'Time (s)','Y (m)','Y Position vs Time','b',2)

