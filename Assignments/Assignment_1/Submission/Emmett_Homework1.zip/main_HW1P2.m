%%% Tucker Emmett for Aerospace Software. This calls the main function
%%% which was written to determine the line of best fit for a set of
%%% lift-vs-alpha data for a scale model of the F-117 Nighthawk.


function [] = main_HW1P2()

mainBestFit();

end