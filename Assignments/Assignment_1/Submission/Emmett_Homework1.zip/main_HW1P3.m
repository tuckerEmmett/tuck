%%% Tucker Emmett for Aerospace Software
%%% This function compiles all of the functions used in Problem 3 and
%%% calculates the maximum altitude of a balloon with the given values of
%%% radius, payload, empty, and MW.

%%% No inputs, though if you wish to determine the maximum
%%% height of a different balloon setup you must change the values found
%%% immediately below for radius, payload, empty, and MW.

%%% Output maximumAltitude (meters) for the current balloon weight configuration.

function [maximumAltitude] = main_HW1P3()

radius = 3; % m
payload = 5; % kg
empty = 0.6 % kg
MW = 4.02 % Molecular weight of helium


[weightTotal] = totalWeight(radius,payload,empty,MW);

[maximumAltitude] = maxAltitude(radius,payload,empty,MW);

 
maximumAltitude
end

