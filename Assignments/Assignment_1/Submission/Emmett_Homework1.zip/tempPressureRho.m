%%% Tucker Emmett for Aerospace Software
%%% This function takes in a desired altitude in meters and outputs local
%%% temperature, pressure, and density. Note that pressure in this case is
%%% in kPa, not straight Pa.

%%% Inputs: altitude (m). This can be an array of any size.
%%% Outputs: T   (C) 
%%%          P   (kPa) 
%%%          rho (kg/m^3)


function [T,P,rho] = tempPressureRho(altitude)

h = altitude; %altitude in meters, T and P and rho in Celsius, kPa, and kg/m^3

if (h>-.000000000001) && (h<=11000)
    
    T = 15.04 - 0.00649.*h;
    P = 101.29.*((T + 273.1)./288.08).^(5.256);
    
elseif (h>11000) && (h<=25000)
    
    T = -56.46;
    P = 22.65.*exp(1.73 - 0.000157.*h);
    
elseif h>25000
    
    T = -131.21 + 0.00299.*h;
    P = 2.488.*((T+273.1)./(216.6)).^(-11.388);
    
else
    disp('Variable h out of scope of problem')
    T = -1;
    P = -1;
end

rho = P./(0.2869.*(T + 273.1));
end
