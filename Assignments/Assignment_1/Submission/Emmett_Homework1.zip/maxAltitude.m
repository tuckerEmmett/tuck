%%% Tucker Emmett for Aerospace Software. This function determines the
%%% current balloon altitude for some set of initial values


%%% Inputs: radius (m). Simple balloon radius used for a volume calculation
%%%         weightPL (kg). Payload weight in kilograms.
%%%         weightE (kg). Empty weight (balloon fabric, basket, etc) in kg.
%%%         MW. Molecular weight of air inside balloon. 

%%% Outputs: currentAlt (m). This function outputs an
%%% altitude at which the buoyant force is no longer greater than the
%%% balloon weight.


function [currentAlt] = maxAltitude(radius,weightPL,weightE,MW)

close all; clc;

w_balloon = totalWeight(radius,weightPL,weightE,MW);
h0 = 0;
disp_w = weightDisplaced(radius,h0);

dH = 10; % 10 m altitude step
while disp_w > w_balloon
    disp_w = weightDisplaced(radius,h0+dH);
    currentAlt = h0+dH;
    h0 = currentAlt+dH;
end

end




